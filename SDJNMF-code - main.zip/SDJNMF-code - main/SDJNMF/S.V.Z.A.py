import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import math
import time
from scipy.stats import pearsonr

start_time = time.time()

data1 = pd.read_csv("../test_data/Pollen_RSEMTopHat.csv")
data2 = pd.read_csv("../test_data/Pollen_kallisto.csv")

num_columns = data1.shape[1]

scaler = MinMaxScaler()
##Construct the similarity matrix S
S1_matrix = np.zeros((num_columns - 1, num_columns - 1))  # Create a zero matrix to store the values of the S1 matrix
S2_matrix = np.zeros((num_columns - 1, num_columns - 1))  # Create a zero matrix to store the values of the S2 matrix

# Compute the S1 matrix
for col1 in range(1, num_columns):
    column1 = data1.iloc[:, col1].values.reshape(-1, 1)
    column1 = scaler.fit_transform(column1)

    min_results = []  # Used to store the three smallest values per row
    min_column_indices = []  # Column index for storing the corresponding minimum value

    for col2 in range(1, num_columns):
        if col1 == col2:
            continue

        column2 = data1.iloc[:, col2].values.reshape(-1, 1)
        column2 = scaler.fit_transform(column2)

        squared_diff_sum = np.sum((column1 - column2) ** 2)
        result = np.sqrt(squared_diff_sum)

        pearson_coefficient, _ = pearsonr(data1.iloc[:, col1], data1.iloc[:, col2])

        min_results.append(result)
        min_column_indices.append(col2)

    # Get the three smallest values in each row
    min_indices = np.argsort(min_results)[:3]
    min_column_indices = np.array(min_column_indices)[min_indices]

    # Set the other elements to 0 according to the index of the smallest value
    for col2 in range(1, num_columns):
        if col2 not in min_column_indices:
            S1_matrix[col1 - 1, col2 - 1] = 0

    # Update the position corresponding to the minimum value
    for i, idx in enumerate(min_indices):
        S1_matrix[col1 - 1, min_column_indices[i] - 1] = math.exp(-(min_results[idx]) ** 2) * pearson_coefficient

S1_df = pd.DataFrame(S1_matrix)

S1_df.to_excel("S1.xlsx", index=False)
# Compute the S2 matrix
for col1 in range(1, num_columns):
    column1 = data2.iloc[:, col1].values.reshape(-1, 1)
    column1 = scaler.fit_transform(column1)

    min_results = []  # 用于存储每行最小的三个值
    min_column_indices = []  # 用于存储对应最小值的列索引

    for col2 in range(1, num_columns):
        if col1 == col2:
            continue

        column2 = data2.iloc[:, col2].values.reshape(-1, 1)
        column2 = scaler.fit_transform(column2)

        squared_diff_sum = np.sum((column1 - column2) ** 2)
        result = np.sqrt(squared_diff_sum)

        pearson_coefficient, _ = pearsonr(data2.iloc[:, col1], data2.iloc[:, col2])

        min_results.append(result)
        min_column_indices.append(col2)


    min_indices = np.argsort(min_results)[:3]
    min_column_indices = np.array(min_column_indices)[min_indices]


    for col2 in range(1, num_columns):
        if col2 not in min_column_indices:
            S2_matrix[col1 - 1, col2 - 1] = 0


    for i, idx in enumerate(min_indices):
        S2_matrix[col1 - 1, min_column_indices[i] - 1] = math.exp(-(min_results[idx]) ** 2) * pearson_coefficient

# Obtain the similarity matrix S
S_matrix = np.where((S1_matrix != 0) & (S2_matrix != 0), S1_matrix + S2_matrix, 0)

## Construct the matrix A
# Compute the sum of each row of the S matrix
row_sums = np.sum(S_matrix, axis=1)

# Create the diagonal matrix A
A = np.diag(row_sums)
A_df = pd.DataFrame(A)

A_df.to_excel("A.xlsx", index=False)

# 将V矩阵转换为DataFrame
S_df = pd.DataFrame(S_matrix)

# 保存为Excel文件
S_df.to_excel("S.xlsx", index=False)
print("Similarity matrix construction complete!")

import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import math
import time
from scipy.stats import pearsonr


## Construct the dissimilarity matrix V
num_columns = data1.shape[1]

scaler = MinMaxScaler()

V1_matrix = np.zeros((num_columns - 1, num_columns - 1))  # Create a zero matrix to store the values of the V1 matrix
V2_matrix = np.zeros((num_columns - 1, num_columns - 1))  # Create a zero matrix to store the values of the V2 matrix

# Compute the V1 matrix
for col1 in range(1, num_columns):
    column1 = data1.iloc[:, col1].values.reshape(-1, 1)
    column1 = scaler.fit_transform(column1)

    max_results = []  # Used to store the maximum three values per row
    max_column_indices = []  # Column index for storing the corresponding maximum value

    for col2 in range(1, num_columns):
        if col1 == col2:
            continue

        column2 = data1.iloc[:, col2].values.reshape(-1, 1)
        column2 = scaler.fit_transform(column2)

        squared_diff_sum = np.sum((column1 - column2) ** 2)
        result = np.sqrt(squared_diff_sum)

        max_results.append(result)
        max_column_indices.append(col2)
        pearson_coefficient, _ = pearsonr(data1.iloc[:, col1], data1.iloc[:, col2])

    # Get the three largest values in each row (the least similar three combined columns)
    max_indices = np.argsort(max_results)[-3:]
    max_column_indices = np.array(max_column_indices)[max_indices]

    # Set the other elements to 0 according to the index of the maximum value
    for col2 in range(1, num_columns):
        if col2 not in max_column_indices:
            V1_matrix[col1 - 1, col2 - 1] = 0

    # Update the position of the corresponding maximum value
    for i, idx in enumerate(max_indices):
        V1_matrix[col1 - 1, max_column_indices[i] - 1] = (1 - math.exp(-(max_results[idx]) ** 2)) * (1 - pearson_coefficient)


# Compute the V2 matrix
for col1 in range(1, num_columns):
    column1 = data2.iloc[:, col1].values.reshape(-1, 1)
    column1 = scaler.fit_transform(column1)

    max_results = []
    max_column_indices = []

    for col2 in range(1, num_columns):
        if col1 == col2:
            continue

        column2 = data2.iloc[:, col2].values.reshape(-1, 1)
        column2 = scaler.fit_transform(column2)

        squared_diff_sum = np.sum((column1 - column2) ** 2)
        result = np.sqrt(squared_diff_sum)

        max_results.append(result)
        max_column_indices.append(col2)
        pearson_coefficient, _ = pearsonr(data2.iloc[:, col1], data2.iloc[:, col2])


    max_indices = np.argsort(max_results)[-3:]
    max_column_indices = np.array(max_column_indices)[max_indices]

    for col2 in range(1, num_columns):
        if col2 not in max_column_indices:
            V2_matrix[col1 - 1, col2 - 1] = 0

    for i, idx in enumerate(max_indices):
        V2_matrix[col1 - 1, max_column_indices[i] - 1] = (1 - math.exp(-(max_results[idx]) ** 2)) * (1 - pearson_coefficient)

# Obtain the dissimilarity matrix V
V_matrix = np.where((V1_matrix != 0) & (V2_matrix != 0), V1_matrix + V2_matrix, 0)

V_df = pd.DataFrame(V_matrix)

V_df.to_excel("V.xlsx", index=False)

print("Dissimilarity matrix construction complete!")

num_columns = data1.shape[1]

scaler = MinMaxScaler()
## Construct the matrix Z
Z1_matrix = np.zeros((num_columns - 1, num_columns - 1))
Z2_matrix = np.zeros((num_columns - 1, num_columns - 1))


for col1 in range(1, num_columns):
    column1 = data1.iloc[:, col1].values.reshape(-1, 1)
    column1 = scaler.fit_transform(column1)

    for col2 in range(1, num_columns):
        if col1 == col2:
            continue

        column2 = data1.iloc[:, col2].values.reshape(-1, 1)
        column2 = scaler.fit_transform(column2)

        squared_diff_sum = np.sum((column1 - column2) ** 2)

        Z1_matrix[col1 - 1, col2 - 1] = squared_diff_sum


for col1 in range(1, num_columns):
    column1 = data2.iloc[:, col1].values.reshape(-1, 1)
    column1 = scaler.fit_transform(column1)

    for col2 in range(1, num_columns):
        if col1 == col2:
            continue

        column2 = data2.iloc[:, col2].values.reshape(-1, 1)
        column2 = scaler.fit_transform(column2)

        squared_diff_sum = np.sum((column1 - column2) ** 2)

        Z2_matrix[col1 - 1, col2 - 1] = squared_diff_sum

# Obtain the Euclidean distance matrix Z
Z_matrix = Z1_matrix + Z2_matrix
Z1_df = pd.DataFrame(Z1_matrix)
Z2_df = pd.DataFrame(Z2_matrix)
Z_df = pd.DataFrame(Z_matrix)

# Z1_df.to_excel("Z1.xlsx", index=False)
# Z2_df.to_excel("Z2.xlsx", index=False)
Z_df.to_excel("Z.xlsx", index=False)

print("Three a priori knowledge matrices are mined!")