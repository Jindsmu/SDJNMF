from sympy import symbols, diff
import numpy as np
import cupy as cp
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import math
from scipy.stats import pearsonr

class sdjnmf_GPU(object):



    def __init__(
            self, D1, D2, W1, W2, H,
            lambda1, lambda2, lambda3, lambda4, lambda5, lambda6,
            S=None, V=None, A=None, Z=None,
            iter_num=1000, conv_judge=1e-5, calc_log=[], regularization='l1'):
        A = pd.read_excel('../SDJNMF/A.xlsx')
        S = pd.read_excel('../SDJNMF/S.xlsx')
        V = pd.read_excel('../SDJNMF/V.xlsx')
        Z = pd.read_excel('../SDJNMF/Z.xlsx')
        self.D1 = cp.asarray(D1)
        self.D2 = cp.asarray(D2)
        self.W1 = cp.asarray(W1)
        self.W2 = cp.asarray(W2)
        self.H = cp.asarray(H)
        self.S = cp.asarray(S)
        self.V = cp.asarray(V)
        self.A = cp.asarray(A)
        self.Z = cp.asarray(Z)
        self.lambda1 = lambda1
        self.lambda2 = lambda2
        self.lambda3 = lambda3
        self.lambda4 = lambda4
        self.lambda5 = lambda5
        self.lambda6 = lambda6
        self.iter_num = iter_num
        self.conv_judge = conv_judge
        self.calc_log = calc_log
        self.regularization = 'l1'



    def __update_W1(self):
        if self.regularization == 'l1':
            self.W1 *= cp.divide(self.D1.dot(self.H.T) - self.lambda2 / 2,
                                 self.W1.dot(self.H.dot(self.H.T)))

    def __update_W2(self):
        if self.regularization == 'l1':
            self.W2 *= cp.divide(self.lambda1 * self.D2.dot(self.H.T) - self.lambda3 / 2,
                                 self.lambda1 * self.W2.dot(self.H.dot(self.H.T)))

    def __update_H(self):
        if self.regularization == 'l1':
            self.H *= cp.divide(
                self.W1.T.dot(self.D1) + self.lambda1 * self.W2.T.dot(self.D2) + 2 * self.lambda5 * self.H.dot(self.S),
                self.W1.T.dot(self.W1.dot(self.H)) + self.lambda1 * self.W2.T.dot(
                    self.W2.dot(self.H)) + 2 * self.lambda5 * self.H.dot(self.A) + self.lambda6 * self.H.dot(self.V))

    def __calc_min_func(self):
        return cp.linalg.norm(self.D1 - self.W1.dot(self.H), ord='fro') ** 2 \
            + self.lambda1 * \
            cp.linalg.norm(self.D2 - self.W2.dot(self.H), ord='fro') ** 2 \
            + self.lambda2 * cp.linalg.norm(self.W1, ord=1) \
            + self.lambda3 * cp.linalg.norm(self.W2, ord=1) \
            + self.lambda4 * cp.linalg.norm(self.H, ord=1) \
            + self.lambda5 * cp.linalg.norm(cp.multiply(self.S, self.Z), ord=1) \
            + self.lambda6 * cp.linalg.norm(cp.multiply(self.V, self.H.T.dot(self.H)), ord=1)



    """
    The main iterative optimisation process used to perform the SDJNMF algorithm.
    The method updates the weight matrices W1, W2 and the potential feature matrix H in iterations of the SDCJNMF algorithm and records the values of the loss function during the iterations and finally returns the updated W1, W2 and H. The method is based on the iterations of the SDCJNMF algorithm.

    In the calc method, pre_min_func denotes the value of the loss function in the previous iteration.
    Then keep updating W1, W2 and H by looping iterations many times and calculate the value of loss function min_func.
    The loop will end prematurely when the convergence condition is satisfied, returning the final W1, W2 and H.

    """

    def calc(self):
        pre_min_func = self.__calc_min_func()

        for cnt in range(self.iter_num):
            '''
            Ensure non-negativity of the matrix
            '''
            self.__update_W1()
            self.W1[self.W1 < cp.finfo(self.W1.dtype).eps] = cp.finfo(
                self.W1.dtype).eps

            self.__update_W2()
            self.W2[self.W2 < cp.finfo(self.W2.dtype).eps] = cp.finfo(
                self.W2.dtype).eps

            self.__update_H()
            self.H[self.H < cp.finfo(self.H.dtype).eps] = cp.finfo(
                self.H.dtype).eps

            min_func = self.__calc_min_func()  # 损失函数的值，在迭代优化过程中被计算和更新。
            self.calc_log.append(min_func)  # 这一行将最新计算得到的min_func值添加到self.calc_log列表中，用于记录每次迭代的最小函数值。

            '''
            Here a convergence check is performed and the iterative loop is exited if the condition is satisfied. The conditions are that the number of iterations cnt (cnt is the counter of the iteration loop) is greater than 10
            and the difference between the minimum function value pre_min_func computed in the previous iteration and the minimum function value min_func computed in the current iteration is less than self.conv_judge.
            '''
            if cnt > 10 and pre_min_func - min_func < self.conv_judge:
                break
            pre_min_func = min_func
        return cp.asnumpy(self.W1), cp.asnumpy(self.W2), cp.asnumpy(self.H)
