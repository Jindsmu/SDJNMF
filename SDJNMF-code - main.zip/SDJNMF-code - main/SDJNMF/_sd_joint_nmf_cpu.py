from sympy import symbols, diff
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
import math
from scipy.stats import pearsonr

class sdjnmf_CPU(object):

    def __init__(
            self, D1, D2, W1, W2, H,
            lambda1, lambda2, lambda3, lambda4, lambda5, lambda6,
            S=None, V=None, A=None, Z=None,
            iter_num=100, conv_judge=1e-5, calc_log=[], regularization='l1'):
        A = pd.read_excel('../SDJNMF/A.xlsx')
        S = pd.read_excel('../SDJNMF/S.xlsx')
        V = pd.read_excel('../SDJNMF/V.xlsx')
        Z = pd.read_excel('../SDJNMF/Z.xlsx')
        self.D1 = D1
        self.D2 = D2
        self.W1 = W1
        self.W2 = W2
        self.H = H
        self.A = A
        self.S = S
        self.V = V
        self.Z = Z
        self.lambda1 = lambda1
        self.lambda2 = lambda2
        self.lambda3 = lambda3
        self.lambda4 = lambda4
        self.lambda5 = lambda5
        self.lambda6 = lambda6
        self.iter_num = iter_num
        self.conv_judge = conv_judge
        self.calc_log = calc_log
        self.regularization = 'l1'


    def __update_W1(self):
        if self.regularization == 'l1':
            self.W1 *= np.divide(self.D1.dot(self.H.T) - self.lambda2 / 2,
                                 self.W1.dot(self.H.dot(self.H.T)))

    def __update_W2(self):
        if self.regularization == 'l1':
            self.W2 *= np.divide(self.lambda1 * self.D2.dot(self.H.T) - self.lambda3 / 2,
                                 self.lambda1 * self.W2.dot(self.H.dot(self.H.T)))

    def __update_H(self):
        if self.regularization == 'l1':
            self.H *= np.divide(
                self.W1.T.dot(self.D1) + self.lambda1 * self.W2.T.dot(self.D2) + 2 * self.lambda5 * self.H.dot(self.S),
                self.W1.T.dot(self.W1.dot(self.H)) + self.lambda1 * self.W2.T.dot(
                    self.W2.dot(self.H) + 2 * self.lambda5 * self.H.dot(self.A)) + self.lambda6 * self.H.dot(self.V))

    def __calc_min_func(self):
        return np.linalg.norm(self.D1 - self.W1.dot(self.H), ord='fro') ** 2 \
            + self.lambda1 * \
            np.linalg.norm(self.D2 - self.W2.dot(self.H), ord='fro') ** 2 \
            + self.lambda2 * np.linalg.norm(self.W1, ord=1) \
            + self.lambda3 * np.linalg.norm(self.W2, ord=1) \
            + self.lambda4 * np.linalg.norm(self.H, ord=1) \
            + self.lambda5 * np.linalg.norm(np.multiply(self.S, self.Z), ord=1) \
            + self.lambda6 * np.linalg.norm(np.multiply(self.V, self.H.dot(self.H.T)), ord=1)



    def calc(self):
        pre_min_func = self.__calc_min_func()

        for cnt in range(self.iter_num):
            self.__update_W1()
            self.W1[self.W1 < np.finfo(self.W1.dtype).eps] = np.finfo(
                self.W1.dtype).eps

            self.__update_W2()
            self.W2[self.W2 < np.finfo(self.W2.dtype).eps] = np.finfo(
                self.W2.dtype).eps

            self.__update_H()
            self.H[self.H < np.finfo(self.H.dtype).eps] = np.finfo(
                self.H.dtype).eps

            min_func = self.__calc_min_func()
            self.calc_log.append(min_func)


            if cnt > 10 and pre_min_func - min_func < self.conv_judge:
                break
            pre_min_func = min_func
        return self.W1, self.W2, self.H
