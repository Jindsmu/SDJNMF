from SDJNMF import SD_JNMF
import numpy as np
import pandas as pd
from sklearn import metrics
from sklearn.metrics.cluster import adjusted_rand_score
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
import time

df1 = pd.read_csv("../test_data/Pollen_RSEMTopHat.csv", index_col=0)
df2 = pd.read_csv("../test_data/Pollen_kallisto.csv", index_col=0)
label = [i.split('_')[0] for i in df1.columns]
df1.columns = label
df2.columns = label


A=[0.1]
B=[0.01]
C=[0.1]

for l4 in A:
    for l5 in B:
        for l6 in C:
            for r in range(11,12):

                SDJNMF = SD_JNMF(df1, df2, rank=r,
                                  lambda1=df1.shape[0] / df2.shape[0],
                                  lambda4=l4,lambda5=l5,lambda6=l6)

                SDJNMF.gene_selection()

                SDJNMF.log_scale()
                start_time = time.time()
                SDJNMF.normalize()
                end_time = time.time()
                SDJNMF.factorize()
                SDJNMF.clustering(cluster_num=len(np.unique(label)))
                ari = adjusted_rand_score(label, SDJNMF.cluster)
                nmi = metrics.normalized_mutual_info_score(label, SDJNMF.cluster)
                execution_time = end_time - start_time
                print('L4='f'{l4}','L5='f'{l5}','L6='f'{l6}','rank='f'{r}',"ARI:", ari,"NMI:",nmi)
                # print('Runtime='f'{execution_time:.5f}')

        #         # 聚类指数
        #         from sklearn.metrics import silhouette_score
        #         from sklearn.metrics import calinski_harabasz_score
        #         silhouette_avg = silhouette_score(df1.T, SDJNMF.cluster)
        #         ch_score = calinski_harabasz_score(df1.T, SDJNMF.cluster)
        #         print(f'{silhouette_avg}', ''f'{ch_score}')



                # #
                # import pandas as pd
                #
                # df_W1 = pd.DataFrame(SDJNMF.W1)  # 假设矩阵W1存储在SD_JNMF.W1中
                # df_W2 = pd.DataFrame(SDJNMF.W2)  # 假设矩阵W1存储在SD_JNMF.W2中
                df_H = pd.DataFrame(SDJNMF.H)   # 假设矩阵H存储在SD_JNMF.H中
                # df_D1 = pd.DataFrame(SDJNMF.D1)  # 假设矩阵D1存储在SD_JNMF.D1中
                # df_D2 = pd.DataFrame(SDJNMF.D2)  # 假设矩阵W1存储在SD_JNMF.D2中
                #
                # # # Output preditct label
                # # df_label=pd.DataFrame(SDJNMF.cluster)
                # # output_path = "../test_data"
                # # output_filename_label = "SDJNMF_label.csv"
                # # df_label.to_csv(output_path + output_filename_label, index=False, header=False)

                # ##Visualisation
                # tsne = TSNE(n_components=2, perplexity=10, random_state=0)
                # X_tsne = tsne.fit_transform(df_H.T)
                #
                # plt.figure(figsize=(8, 6))
                # # 设置横纵坐标的字体为Times New Roman，字体大小为12
                # plt.xticks(fontfamily='Times New Roman', fontsize=12)
                # plt.yticks(fontfamily='Times New Roman', fontsize=12)
                # plt.title('t-SNE',fontfamily='Times New Roman', fontsize=15)
                # plt.scatter(X_tsne[:, 0], X_tsne[:, 1], c=SDJNMF.cluster)
                # plt.show()



                # output_path = "../test_data"
                # output_filename_W1 = "W1_matrix.xlsx"
                # output_filename_W2 = "W2_matrix.xlsx"
                # output_filename_H = "H1_matrix.xlsx"
                # output_filename_D1 = "D1_matrix.xlsx"
                # output_filename_D2 = "D2_matrix.xlsx"

                # df_W1.to_excel(output_path + output_filename_W1, index=False)
                # df_W2.to_excel(output_path + output_filename_W2, index=False)
                # df_H.to_excel(output_path + output_filename_H, index=False)
                # df_D1.to_excel(output_path + output_filename_D1, index=False)
                # df_D2.to_excel(output_path + output_filename_D2, index=False)
                #
                # print("Matrix W, H, and D saved as Excel files.")
