# import unittest
# import cupy as cp
# import numpy as np
# from SDJNMF import sdjnmf


# class TestSD_jnmf(unittest.TestCase):
#     def test_normalize(self):
#         d1 = np.random.randint(4, size=(10, 10))
#         d2 = np.random.randint(5, size=(10, 10))
#         sdjnmf = SDJNMF(d1, d2, rank=3)
